#include"sp_iic.h"

//依赖
#include<string.h>
#include"driver/i2c_master.h"

//配置
#define SP_IIC0_DEV I2C_NUM_0
#define SP_IIC0_SCL_PIN 2
#define SP_IIC0_SDA_PIN 3
#define SP_IIC0_DEV0_ADDR 0x38
#define SP_IIC0_DEV0_RATE (400*1000)
#define SP_IIC0_DEV1_ADDR 0x00
#define SP_IIC0_DEV1_RATE (400*1000)

//IIC0数据
typedef struct iic0_data_t
{
    i2c_master_bus_handle_t bus_handle;
    i2c_master_dev_handle_t dev0;
    // u16 dev0_addr;
    // u16 dev0_speed;
    i2c_master_dev_handle_t dev1;
    // u16 dev1_addr;
    // u16 dev1_speed;
}iic0_data_t;
static iic0_data_t*iic0_data=NULL;


//IIC0初始化
sp_t sp_iic0_init();
//IIC0反初始化
sp_t sp_iic0_deinit();
//IIC0传输
sp_t sp_iic0_trans(u8 dev_num, u8* tx_data, u32 tx_len, u8* rx_data, u32 rx_len);

//IIC0初始化
sp_t sp_iic0_init()
{
    //申请内存
    iic0_data = malloc(sizeof(iic0_data_t));
    if(!iic0_data)
    {
        SP_LOG("mem err");
        return SP_FAIL;
    }
    memset(iic0_data, 0, sizeof(iic0_data_t));
    //初始化IIC0总线
    i2c_master_bus_config_t bus_config={0};
    bus_config.clk_source = I2C_CLK_SRC_DEFAULT;
    bus_config.i2c_port = SP_IIC0_DEV;
    bus_config.scl_io_num = SP_IIC0_SCL_PIN;
    bus_config.sda_io_num = SP_IIC0_SDA_PIN;
    bus_config.glitch_ignore_cnt = 7;
    bus_config.flags.enable_internal_pullup = true;
    ESP_ERROR_CHECK(i2c_new_master_bus(&bus_config, &iic0_data->bus_handle));
    //添加设备0 (地址不为0时添加)
    if(SP_IIC0_DEV0_ADDR)
    {
        i2c_device_config_t dev_config={0};
        dev_config.dev_addr_length = I2C_ADDR_BIT_LEN_7;
        dev_config.device_address = SP_IIC0_DEV0_ADDR;
        dev_config.scl_speed_hz = SP_IIC0_DEV0_RATE;
        ESP_ERROR_CHECK(i2c_master_bus_add_device(iic0_data->bus_handle, &dev_config, &iic0_data->dev0));
        SP_LOG("dev0 add succ");
    }
    //添加设备1 (地址不为0时添加)
    if(SP_IIC0_DEV1_ADDR)
    {
        i2c_device_config_t dev_config={0};
        dev_config.dev_addr_length = I2C_ADDR_BIT_LEN_7;
        dev_config.device_address = SP_IIC0_DEV1_ADDR;
        dev_config.scl_speed_hz = SP_IIC0_DEV1_RATE;
        ESP_ERROR_CHECK(i2c_master_bus_add_device(iic0_data->bus_handle, &dev_config, &iic0_data->dev1));
        SP_LOG("dev1 add succ");
    }
    SP_LOG("init ok");
    return SP_OK;
}

//IIC0反初始化
sp_t sp_iic0_deinit()
{
    if(!iic0_data)
    {
        SP_LOG("not init");
        return SP_FAIL;
    }
    //移除所有设备
    if(iic0_data->dev0)
    {
        i2c_master_bus_rm_device(iic0_data->dev0);
    }
    if(iic0_data->dev1)
    {
        i2c_master_bus_rm_device(iic0_data->dev1);
    }
    //释放IIC0总线
    if(iic0_data->bus_handle)
    {
        i2c_del_master_bus(iic0_data->bus_handle);
    }
    //释放内存
    free(iic0_data);
    iic0_data = NULL;
    SP_LOG("deinit ok");
    return SP_OK;
}

//IIC0传输
sp_t sp_iic0_trans(u8 dev_num, u8* tx_data, u32 tx_len, u8* rx_data, u32 rx_len)
{
    if(!iic0_data)
    {
        SP_LOG("not init");
        return SP_FAIL;
    }
    i2c_master_dev_handle_t dev_handle = NULL;
    //根据设备编号选择设备句柄
    switch(dev_num)
    {
        case 0:
            dev_handle = iic0_data->dev0;
            break;
        case 1:
            dev_handle = iic0_data->dev1;
            break;
        default:
            SP_LOG("invalid dev num: %d", dev_num);
            return SP_FAIL;
    }
    //检查设备是否存在
    if(!dev_handle)
    {
        SP_LOG("dev %d not exist", dev_num);
        return SP_FAIL;
    }
    esp_err_t ret = ESP_OK;
    //执行IIC传输
    if(tx_len > 0 && rx_len > 0)
    {
        //先写后读模式
        ret = i2c_master_transmit_receive(dev_handle, tx_data, tx_len, rx_data, rx_len, -1);
    }
    else if(tx_len > 0)
    {
        //只写模式
        ret = i2c_master_transmit(dev_handle, tx_data, tx_len, -1);
    }
    else if(rx_len > 0)
    {
        //只读模式
        ret = i2c_master_receive(dev_handle, rx_data, rx_len, -1);
    }
    else
    {
        //无效参数
        SP_LOG("invalid parameters: both tx_len and rx_len are 0");
        return SP_FAIL;
    }
    if(ret != ESP_OK)
    {
        SP_LOG("transmit fail: %d", ret);
        return SP_FAIL;
    }
    return SP_OK;
}
