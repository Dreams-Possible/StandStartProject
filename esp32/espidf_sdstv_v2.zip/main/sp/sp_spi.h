#pragma once

//SP库支持
#include"sp_sys.h"

//SPI0初始化
sp_t sp_spi0_init();
//SPI0反初始化
sp_t sp_spi0_deinit();
//SPI0传输
sp_t sp_spi0_trans(u8 dev_num, u8* tx_data, u32 tx_len, u8* rx_data, u32 rx_len);
