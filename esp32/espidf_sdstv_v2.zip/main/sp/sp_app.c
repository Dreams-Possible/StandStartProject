#include"sp_app.h"

#include"sp_uart.h"
#include"sp_ltfs.h"
#include"sp_iic.h"
#include"sp_spi.h"


//用户应用
void sp_app();

//用户应用
void sp_app()
{
    //串口0初始化
    while(sp_uart0_init()!=SP_OK)
    {
        SP_DELAY(1000);
    }
    //LittleFS初始化
    while(sp_ltfs_init()!=SP_OK)
    {
        SP_DELAY(1000);
    }
    //IIC0初始化
    while(sp_iic0_init()!=SP_OK)
    {
        SP_DELAY(1000);
    }
    //SPI0初始化
    while(sp_spi0_init()!=SP_OK)
    {
        SP_DELAY(1000);
    }
    while(1)
    {
        //从串口输入
        u8*data=NULL;
        u16 len=0;
        sp_uart0_rx_bin(&data,&len);
        sp_uart0_tx_bin(data,len);
    }
}
