#pragma once

//类型定义
#include<stdint.h>
#include<stdbool.h>
typedef uint8_t u8;
typedef int8_t i8;
typedef uint16_t u16;
typedef int16_t i16;
typedef uint32_t u32;
typedef int32_t i32;
typedef u8 sp_t;
#define SP_OK 0
#define SP_FAIL 1

//日志定义
#include"esp_log.h"
#define SP_LOG(fmt,...) ESP_LOGI("[SP_INFO]","[%s:%d:%s]: "fmt" ",__FILE__,__LINE__,__func__,##__VA_ARGS__)

//RTOS支持
#include"freertos/FreeRTOS.h"
#include"freertos/task.h"
#include"freertos/queue.h"
#include"freertos/semphr.h"
#define SP_DELAY(ms) vTaskDelay(pdMS_TO_TICKS(ms))
