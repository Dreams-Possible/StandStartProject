#pragma once

//SP库支持
#include"sp_sys.h"

//LittleFS初始化
sp_t sp_ltfs_init();
