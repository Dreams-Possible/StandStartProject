#include"sp_uart.h"

//依赖
// #include <stdio.h>
// #include <string.h>
// #include <sys/stat.h>
// #include <unistd.h>
// #include "esp_err.h"
// #include "esp_log.h"
// #include "esp_system.h"
#include "esp_littlefs.h"

//LittleFS初始化
sp_t sp_ltfs_init();

//LittleFS初始化
sp_t sp_ltfs_init()
{
    SP_LOG("init littlefs");
    esp_vfs_littlefs_conf_t conf =
    {
        .base_path = "/ltfs",
        .partition_label = "storage",
        .format_if_mount_failed = false,
        .dont_mount = false,
    };
    // 使用上述配置初始化和挂载 LittleFS 文件系统
    // 注意：esp_vfs_littlefs_register 是一个一体化的便捷函数
    esp_err_t ret = esp_vfs_littlefs_register(&conf);
    if (ret != ESP_OK)
    {
        if (ret == ESP_FAIL)
        {
            SP_LOG("can not mount filesystem");
        }
        else
        if (ret == ESP_ERR_NOT_FOUND)
        {
            SP_LOG("can not find partition");
        }else
        {
            SP_LOG("can not initialize littlefs (esp err: %s)", esp_err_to_name(ret));
        }
        return 1;
    }
    // 获取分区信息
    size_t total = 0, used = 0;
    ret = esp_littlefs_info(conf.partition_label, &total, &used);
    if (ret != ESP_OK)
    {
        SP_LOG("can not get partition information (esp err: %s)", esp_err_to_name(ret));
        // esp_littlefs_format(conf.partition_label);
    }else
    {
        SP_LOG("partition size: total: %d, used: %d", total, used);
    }
    // // 全部完成，卸载分区并禁用 LittleFS
    // esp_vfs_littlefs_unregister(conf.partition_label);
    // SP_LOG("littlefs unmounted");
    SP_LOG("littlefs init success");
    return 0;
}
