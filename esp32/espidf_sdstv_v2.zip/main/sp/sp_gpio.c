#include"sp_uart.h"

//依赖
#include<string.h>
#include"driver/gpio.h"

//初始化引脚
void sp_gpio_init(u8 num,u8 io);
//设置引脚
void sp_gpio_set(u8 num,u8 level);
//读取引脚
u8 sp_gpio_get(u8 num);

//初始化引脚
void sp_gpio_init(u8 num,u8 io)
{
    gpio_config_t config={0};
    //dc pin
    config.intr_type=GPIO_INTR_DISABLE;
    if(io)
    {
        config.mode=GPIO_MODE_INPUT;
    }else
    {
        config.mode=GPIO_MODE_OUTPUT;
    }
    config.pin_bit_mask=(1ULL<<num);
    config.pull_down_en=0;
    config.pull_up_en=0;
    ESP_ERROR_CHECK(gpio_config(&config));
}

//设置引脚
void sp_gpio_set(u8 num,u8 level)
{
    ESP_ERROR_CHECK(gpio_set_level(num,level));
}

//读取引脚
u8 sp_gpio_get(u8 num)
{
    return (u8)gpio_get_level(num);
}
