#pragma once

//SP库支持
#include"sp_sys.h"

//IIC0初始化
sp_t sp_iic0_init();
//IIC0反初始化
sp_t sp_iic0_deinit();
//IIC0传输
sp_t sp_iic0_trans(u8 dev_num, u8* tx_data, u32 tx_len, u8* rx_data, u32 rx_len);
