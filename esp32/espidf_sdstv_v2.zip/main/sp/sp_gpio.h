#pragma once

//SP库支持
#include"sp_sys.h"

//初始化引脚
void sp_gpio_init(u8 num,u8 io);
//设置引脚
void sp_gpio_set(u8 num,u8 level);
//读取引脚
u8 sp_gpio_get(u8 num);
