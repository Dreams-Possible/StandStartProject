#include"sp_uart.h"

//依赖
#include<string.h>
#include"driver/uart.h"

//配置
#define SP_UART0_TX_PIN UART_PIN_NO_CHANGE
#define SP_UART0_RX_PIN UART_PIN_NO_CHANGE
#define SP_UART0_PORT UART_NUM_0
#define SP_UART0_RATE 1152000
#define SP_UART0_MAX_TX_LEN 1*1024
#define SP_UART0_MAX_RX_LEN 1*1024

//UART0数据
typedef struct uart0_data_t
{
    u8 rx_data[SP_UART0_MAX_RX_LEN];
    u8 tx_data[SP_UART0_MAX_TX_LEN];
    // QueueHandle_t uart_event;
    // SemaphoreHandle_t rx_event;
    // u16 rx_len;
}uart0_data_t;
static uart0_data_t*uart0_data=NULL;

// //串口0接收服务
// static void uart0_rx_task(void*arg);
//串口0初始化
sp_t sp_uart0_init();
//串口0反初始化
sp_t sp_uart0_deinit();
// //串口0接收
// char*sp_uart0_rx();
//串口0接收字节
void sp_uart0_rx_bin(u8**data,u16*len);
//串口0发送
void sp_uart0_tx(char*data,...);
//串口0发送字节
void sp_uart0_tx_bin(u8*data,u16 len);

// //串口0接收服务
// static void uart0_rx_task(void*arg)
// {
//     while(1)
//     {
//         //阻塞直到有串口0事件
//         uart_event_t event={0};
//         if(xQueueReceive(uart0_data->uart_event,&event,portMAX_DELAY))
//         {
//             //如果是收到数据
//             if(event.type==UART_DATA)
//             {
//                 //重新读取
//                 memset(uart0_data->rx_data,0,uart0_data->rx_len);
//                 uart0_data->rx_len=event.size;
//                 uart_read_bytes(SP_UART0_PORT,uart0_data->rx_data,event.size,portMAX_DELAY);
//                 //收到新串口0数据
//                 xSemaphoreGive(uart0_data->rx_event);
//             }
//         }
//     }
// }

//串口0初始化
sp_t sp_uart0_init()
{
    //申请内存
    uart0_data=malloc(sizeof(uart0_data_t));
    if(!uart0_data)
    {
        SP_LOG("mem err");
        return SP_FAIL;
    }
    memset(uart0_data,0,sizeof(uart0_data_t));
    // uart0_data->rx_event=xSemaphoreCreateBinary();
    // if(!uart0_data->rx_event)
    // {
    //     SP_LOG("semaphore create fail");
    //     return SP_FAIL;
    // }
    // uart0_data->rx_len=0;
    // esp_err_t ret=ESP_OK;
    //配置串口0参数
    uart_config_t config={0};
    config.baud_rate=SP_UART0_RATE;
    config.data_bits=UART_DATA_8_BITS;
    config.parity=UART_PARITY_DISABLE;
    config.stop_bits=UART_STOP_BITS_1;
    config.flow_ctrl=UART_HW_FLOWCTRL_DISABLE;
    config.source_clk=UART_SCLK_DEFAULT;
    // //临时关闭LOG确保输出干净
    // esp_log_level_set("*", ESP_LOG_NONE);
    //安装串口0驱动
    ESP_ERROR_CHECK(uart_driver_install(SP_UART0_PORT,SP_UART0_MAX_RX_LEN,SP_UART0_MAX_TX_LEN,0,NULL,0));
    //配置串口0
    ESP_ERROR_CHECK(uart_param_config(SP_UART0_PORT,&config));
    //配置串口0引脚
    ESP_ERROR_CHECK(uart_set_pin(SP_UART0_PORT,SP_UART0_TX_PIN,SP_UART0_RX_PIN,UART_PIN_NO_CHANGE,UART_PIN_NO_CHANGE));
    // SP_DELAY(10);
    // //重新打开LOG输出
    // esp_log_level_set("*", ESP_LOG_INFO);
    // //创建串口0接收任务
    // if(xTaskCreate(uart0_rx_task,"uart0_rx_task",1024*2,NULL,8,NULL) != pdPASS)
    // {
    //     SP_LOG("task create fail");
    //     //删除信号量
    //     if(uart0_data->rx_event)
    //     {
    //         vSemaphoreDelete(uart0_data->rx_event);
    //     }
    //     //删除事件队列
    //     if(uart0_data->uart_event)
    //     {
    //         vQueueDelete(uart0_data->uart_event);
    //     }
    //     //卸载串口0驱动
    //     uart_driver_delete(SP_UART0_PORT);
    //     //释放内存
    //     free(uart0_data);
    //     uart0_data = NULL;
    //     return SP_FAIL;
    // }
    //串口0初始化成功
    SP_LOG("init ok");
    return SP_OK;
}

//串口0反初始化
sp_t sp_uart0_deinit()
{
    if(!uart0_data)
    {
        SP_LOG("not init");
        return SP_FAIL;
    }
    //卸载UART驱动
    uart_driver_delete(SP_UART0_PORT);
    //释放内存
    free(uart0_data);
    uart0_data = NULL;
    SP_LOG("deinit ok");
    return SP_OK;
}

//串口0接收字符串
char*sp_uart0_rx_char()
{
    //等待接收
    uart_read_bytes(SP_UART0_PORT,uart0_data->rx_data,SP_UART0_MAX_RX_LEN-1,portMAX_DELAY);
    //返回接收的数据
    return (char*)uart0_data->rx_data;
}

//串口0接收比特流
void sp_uart0_rx_bin(u8**data,u16*len)
{
    // SP_LOG("wait");
    //等待接收
    // xSemaphoreTake(uart0_data->rx_event,portMAX_DELAY);
    int rx_len=0;
    while(1)
    {
        rx_len=uart_read_bytes(SP_UART0_PORT,uart0_data->rx_data,SP_UART0_MAX_RX_LEN-1,pdMS_TO_TICKS(1));
        if(rx_len>0)
        {
            break;
        }
    }
    // SP_LOG("len=%d",len);
    //返回接收的数据
    // *data=(u8*)&uart0_data->rx_data;
    *data=uart0_data->rx_data;
    // SP_LOG("data=%s",uart0_data->rx_data);
    //返回接收的数据长度
    if(len)
    {
        *len=(u16)rx_len;
    }
}

//串口0发送字符串
void sp_uart0_tx(char*data,...)
{
    //更新发送缓冲区
    memset(uart0_data->tx_data,0,SP_UART0_MAX_TX_LEN);
    //生成字符串
    va_list val;
    va_start(val,data);
    vsnprintf((char*)uart0_data->tx_data,SP_UART0_MAX_TX_LEN,data,val);
    va_end(val);
    //串口0发送
    uart_write_bytes(SP_UART0_PORT,(const void*)uart0_data->tx_data,strlen((char*)uart0_data->tx_data));
}

//串口0发送比特流
void sp_uart0_tx_bin(u8*data,u16 len)
{
    //串口0发送
    uart_write_bytes(SP_UART0_PORT,(const void*)data,len);
}
