#include"sp_spi.h"

//依赖
#include<string.h>
#include"driver/spi_master.h"

//配置
#define SP_SPI0_DEV SPI2_HOST
#define SP_SPI0_SCLK_PIN 12
#define SP_SPI0_MOSI_PIN 11
#define SP_SPI0_MISO_PIN 13
#define SP_SPI0_CS0_PIN 10
#define SP_SPI0_DEV0_RATE (60*1000*1000)
#define SP_SPI0_CS1_PIN 0
#define SP_SPI0_DEV1_RATE (40*1000*1000)
#define SP_SPI0_CS2_PIN 0
#define SP_SPI0_DEV2_RATE (40*1000*1000)
#define SP_SPI0_CS3_PIN 0
#define SP_SPI0_DEV3_RATE (40*1000*1000)

//SPI0数据
typedef struct spi0_data_t
{
    spi_device_handle_t dev0;
    spi_device_handle_t dev1;
}spi0_data_t;
static spi0_data_t*spi0_data=NULL;


//SPI0初始化
sp_t sp_spi0_init();
//SPI0反初始化
sp_t sp_spi0_deinit();
//SPI0传输
sp_t sp_spi0_trans(u8 dev_num, u8* tx_data, u32 tx_len, u8* rx_data, u32 rx_len);

//SPI0初始化
sp_t sp_spi0_init()
{
    //申请内存
    spi0_data = malloc(sizeof(spi0_data_t));
    if(!spi0_data)
    {
        SP_LOG("mem err");
        return SP_FAIL;
    }
    memset(spi0_data, 0, sizeof(spi0_data_t));
    //初始化SPI0总线
    spi_bus_config_t config={0};
    config.mosi_io_num=SP_SPI0_MOSI_PIN;
    config.miso_io_num=SP_SPI0_MISO_PIN;
    config.sclk_io_num=SP_SPI0_SCLK_PIN;
    config.quadwp_io_num=-1;
    config.quadhd_io_num=-1;
    config.max_transfer_sz=1024*32*8;
    ESP_ERROR_CHECK(spi_bus_initialize(SP_SPI0_DEV,&config,SPI_DMA_CH_AUTO));
    //添加设备0 (CS0_PIN不为0时添加)
    if(SP_SPI0_CS0_PIN)
    {
        spi_device_interface_config_t dev_config={0};
        dev_config.mode=0;
        dev_config.spics_io_num=SP_SPI0_CS0_PIN;
        dev_config.queue_size=1;
        dev_config.clock_speed_hz=SP_SPI0_DEV0_RATE;
        ESP_ERROR_CHECK(spi_bus_add_device(SP_SPI0_DEV,&dev_config,&spi0_data->dev0));
    }
    //添加设备1 (CS1_PIN不为0时添加)
    if(SP_SPI0_CS1_PIN)
    {
        spi_device_interface_config_t dev_config={0};
        dev_config.mode=0;
        dev_config.spics_io_num=SP_SPI0_CS1_PIN;
        dev_config.queue_size=1;
        dev_config.clock_speed_hz=SP_SPI0_DEV1_RATE;
        ESP_ERROR_CHECK(spi_bus_add_device(SP_SPI0_DEV,&dev_config,&spi0_data->dev1));
    }
    SP_LOG("init ok");
    return SP_OK;
}

//SPI0反初始化
sp_t sp_spi0_deinit()
{
    if(!spi0_data)
    {
        SP_LOG("not init");
        return SP_FAIL;
    }
    //移除所有设备
    if(spi0_data->dev0)
    {
        spi_bus_remove_device(spi0_data->dev0);
    }
    if(spi0_data->dev1)
    {
        spi_bus_remove_device(spi0_data->dev1);
    }
    //释放SPI0总线
    spi_bus_free(SP_SPI0_DEV);
    //释放内存
    free(spi0_data);
    spi0_data = NULL;
    SP_LOG("deinit ok");
    return SP_OK;
}

//SPI0传输
sp_t sp_spi0_trans(u8 dev_num, u8* tx_data, u32 tx_len, u8* rx_data, u32 rx_len)
{
    if(!spi0_data)
    {
        SP_LOG("not init");
        return SP_FAIL;
    }
    spi_device_handle_t dev_handle = NULL;
    //根据设备编号选择设备句柄
    switch(dev_num)
    {
        case 0:
            dev_handle = spi0_data->dev0;
            break;
        case 1:
            dev_handle = spi0_data->dev1;
            break;
        default:
            SP_LOG("invalid dev num: %d", dev_num);
            return SP_FAIL;
    }
    //检查设备是否存在
    if(!dev_handle)
    {
        SP_LOG("dev %d not exist", dev_num);
        return SP_FAIL;
    }
    //创建SPI传输
    spi_transaction_t trans={0};
    //设置传输长度
    if(tx_len > 0 && rx_len > 0)
    {
        //全双工模式：同时发送和接收
        trans.length = tx_len * 8;
        trans.rxlength = rx_len * 8;
        trans.tx_buffer = tx_data;
        trans.rx_buffer = rx_data;
    }
    else
    if(tx_len > 0)
    {
        //只发送模式
        trans.length = tx_len * 8;
        trans.rxlength = 0;
        trans.tx_buffer = tx_data;
        trans.rx_buffer = NULL;
    }
    else
    if(rx_len > 0)
    {
        //只接收模式
        trans.length = rx_len * 8;
        trans.rxlength = rx_len * 8;
        trans.tx_buffer = NULL;
        trans.rx_buffer = rx_data;
    }
    else
    {
        //无效参数
        SP_LOG("invalid parameters: both tx_len and rx_len are 0");
        return SP_FAIL;
    }
    //SPI传输
    esp_err_t ret = spi_device_transmit(dev_handle, &trans);
    if(ret != ESP_OK)
    {
        SP_LOG("transmit fail: %d", ret);
        return SP_FAIL;
    }
    return SP_OK;
}
