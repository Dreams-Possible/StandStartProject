#pragma once

//SP库支持
#include"sp_sys.h"

// //串口0接收服务
// static void uart0_rx_task(void*arg);
//串口0初始化
sp_t sp_uart0_init();
//串口0反初始化
sp_t sp_uart0_deinit();
// //串口0接收
// char*sp_uart0_rx();
//串口0接收字节
void sp_uart0_rx_bin(u8**data,u16*len);
//串口0发送
void sp_uart0_tx(char*data,...);
//串口0发送字节
void sp_uart0_tx_bin(u8*data,u16 len);
