################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Main/Platform/pl_encoder.c \
../Main/Platform/pl_iic.c \
../Main/Platform/pl_key.c \
../Main/Platform/pl_motor.c \
../Main/Platform/pl_spi.c \
../Main/Platform/pl_sys.c \
../Main/Platform/pl_uart.c 

OBJS += \
./Main/Platform/pl_encoder.o \
./Main/Platform/pl_iic.o \
./Main/Platform/pl_key.o \
./Main/Platform/pl_motor.o \
./Main/Platform/pl_spi.o \
./Main/Platform/pl_sys.o \
./Main/Platform/pl_uart.o 

C_DEPS += \
./Main/Platform/pl_encoder.d \
./Main/Platform/pl_iic.d \
./Main/Platform/pl_key.d \
./Main/Platform/pl_motor.d \
./Main/Platform/pl_spi.d \
./Main/Platform/pl_sys.d \
./Main/Platform/pl_uart.d 


# Each subdirectory must supply rules for building sources it contributes
Main/Platform/%.o Main/Platform/%.su Main/Platform/%.cyclo: ../Main/Platform/%.c Main/Platform/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM3 -I"C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.19.0/stm32ide_sdst_pro/Main" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Main-2f-Platform

clean-Main-2f-Platform:
	-$(RM) ./Main/Platform/pl_encoder.cyclo ./Main/Platform/pl_encoder.d ./Main/Platform/pl_encoder.o ./Main/Platform/pl_encoder.su ./Main/Platform/pl_iic.cyclo ./Main/Platform/pl_iic.d ./Main/Platform/pl_iic.o ./Main/Platform/pl_iic.su ./Main/Platform/pl_key.cyclo ./Main/Platform/pl_key.d ./Main/Platform/pl_key.o ./Main/Platform/pl_key.su ./Main/Platform/pl_motor.cyclo ./Main/Platform/pl_motor.d ./Main/Platform/pl_motor.o ./Main/Platform/pl_motor.su ./Main/Platform/pl_spi.cyclo ./Main/Platform/pl_spi.d ./Main/Platform/pl_spi.o ./Main/Platform/pl_spi.su ./Main/Platform/pl_sys.cyclo ./Main/Platform/pl_sys.d ./Main/Platform/pl_sys.o ./Main/Platform/pl_sys.su ./Main/Platform/pl_uart.cyclo ./Main/Platform/pl_uart.d ./Main/Platform/pl_uart.o ./Main/Platform/pl_uart.su

.PHONY: clean-Main-2f-Platform

