################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../SP/User/us_app.c 

OBJS += \
./SP/User/us_app.o 

C_DEPS += \
./SP/User/us_app.d 


# Each subdirectory must supply rules for building sources it contributes
SP/User/%.o SP/User/%.su SP/User/%.cyclo: ../SP/User/%.c SP/User/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM3 -I"C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.19.0/sp_sdst/SP" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-SP-2f-User

clean-SP-2f-User:
	-$(RM) ./SP/User/us_app.cyclo ./SP/User/us_app.d ./SP/User/us_app.o ./SP/User/us_app.su

.PHONY: clean-SP-2f-User

