################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../SP/Platform/sp_sys.c \
../SP/Platform/sp_uart.c 

OBJS += \
./SP/Platform/sp_sys.o \
./SP/Platform/sp_uart.o 

C_DEPS += \
./SP/Platform/sp_sys.d \
./SP/Platform/sp_uart.d 


# Each subdirectory must supply rules for building sources it contributes
SP/Platform/%.o SP/Platform/%.su SP/Platform/%.cyclo: ../SP/Platform/%.c SP/Platform/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM3 -I"C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.19.0/sp_sdst/SP" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-SP-2f-Platform

clean-SP-2f-Platform:
	-$(RM) ./SP/Platform/sp_sys.cyclo ./SP/Platform/sp_sys.d ./SP/Platform/sp_sys.o ./SP/Platform/sp_sys.su ./SP/Platform/sp_uart.cyclo ./SP/Platform/sp_uart.d ./SP/Platform/sp_uart.o ./SP/Platform/sp_uart.su

.PHONY: clean-SP-2f-Platform

