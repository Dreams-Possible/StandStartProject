#pragma once

//依赖
#include"pl_sys.h"

//CubeIDE中按如下配置
//设置定时器为编码器模式
//其余默认即可

//编码器总初始化
pl_t pl_encoders_init();
//编码器总读取
void pl_encoders_read(float*encoder1,float*encoder2);
