#pragma once
#include"pl_sys.h"

//CubeIDE中按如下配置
//默认硬件上按键一极接地，一极接引脚
//任意引脚命名为：Keyx
//推挽输出，初始高，默认上拉
//其余默认即可

//按键初始化
pl_t pl_key_init();
//按键读取
void pl_key_read(u8*key1,u8*key2);
