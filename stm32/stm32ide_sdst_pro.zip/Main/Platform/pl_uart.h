#pragma once

//依赖
#include"pl_sys.h"

//CubeIDE中按如下配置
//启用串口
//启用TX和RX的DMA通道
//启用串口中断
//其余默认即可

//串口1发送字符串
void pl_uart1_tx_str(const char*data,...);
//串口1发送二进制
void pl_uart1_tx_bin(u8*data,u16 len);
//串口1接收字符串
void pl_uart1_rx_str(char*data,u16 len);
//串口1接收二进制
void pl_uart1_rx_bin(u8*data,u16*len);
//串口1超时接收字符串
pl_t pl_uart1_rx_str_time(u16 time,char*data,u16 len);
//串口1超时接收二进制
pl_t pl_uart1_rx_bin_time(u16 time,u8*data,u16*len);
