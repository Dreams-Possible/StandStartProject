#include"pl_encoder.h"

//定义
extern TIM_HandleTypeDef htim2;
#define encoder1_timer htim2
extern TIM_HandleTypeDef htim3;
#define encoder2_timer htim3

//编码器数据
typedef struct encoder_data_t
{
	float encoder1;
	float encoder2;
}encoder_data_t;
static encoder_data_t encoder_data={0};

//编码器1初始化
static pl_t encoder1_init();
//编码器2初始化
static pl_t encoder2_init();
//编码器总初始化
pl_t pl_encoders_init();
//编码器总任务
static void encoders_scan(void*arg);
//编码器1读取
static void encoder1_read();
//编码器2读取
static void encoder2_read();
//编码器总读取
void pl_encoders_read(float*encoder1,float*encoder2);

//编码器1初始化
static pl_t encoder1_init()
{
	if(HAL_TIM_Encoder_Start(&encoder1_timer,TIM_CHANNEL_ALL)!=HAL_OK)
	{
		return PL_FAIL;
	}
	return PL_OK;
}

//编码器2初始化
static pl_t encoder2_init()
{
	if(HAL_TIM_Encoder_Start(&encoder2_timer,TIM_CHANNEL_ALL)!=HAL_OK)
	{
		return PL_FAIL;
	}
	return PL_OK;
}

//编码器总初始化
pl_t pl_encoders_init()
{
	if(encoder1_init()!=PL_OK)
	{
		return PL_FAIL;
	}
	if(encoder2_init()!=PL_OK)
	{
		return PL_FAIL;
	}
	osThreadAttr_t ThreadAttr=
	{
		.name="encoders_scan",
		.stack_size=128*4,
		.priority=(osPriority_t)osPriorityNormal,
	};
	osThreadId_t encoder_scan = osThreadNew(encoders_scan,NULL,&ThreadAttr);
	if(!encoder_scan)
	{
		return PL_FAIL;
	}
	return PL_OK;
}

//编码器总任务
static void encoders_scan(void*arg)
{
	while (1)
	{
		encoder1_read();
		encoder2_read();
		// PL_LOG("encder run");
		osDelay(50);
	}
}

//编码器1读取
static void encoder1_read()
{
	//检测
	encoder_data.encoder1=(i16)__HAL_TIM_GetCounter(&encoder1_timer);
	//重置
	__HAL_TIM_SetCounter(&encoder1_timer,0);
}

//编码器2读取
static void encoder2_read()
{
	//检测
	encoder_data.encoder2=(i16)__HAL_TIM_GetCounter(&encoder2_timer);
	//重置
	__HAL_TIM_SetCounter(&encoder2_timer,0);
}

//编码器读取
void pl_encoders_read(float*encoder1,float*encoder2)
{
	encoder1_read();
	if(encoder1)
	{
		*encoder1=encoder_data.encoder1;
	}
	encoder2_read();
	if(encoder2)
	{
		*encoder2=encoder_data.encoder2;
	}
}
