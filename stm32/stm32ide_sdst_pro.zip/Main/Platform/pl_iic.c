#include"pl_iic.h"

//配置
extern I2C_HandleTypeDef hi2c2;
#define IIC1 hi2c2
#define IIC1_OVERTIME 100

//IIC1等待
static pl_t iic1_wait();
//IIC1检查
static pl_t iic1_check();
//IIC1写数据
pl_t pl_iic1_wt_data(u8 dev_addr,u8*data,u16 len);
//IIC1读数据
pl_t pl_iic1_rd_data(u8 dev_addr,u8*data,u16 len);
//IIC1写寄存器
pl_t pl_iic1_wt_addr(u8 dev_addr,u8 reg_addr,u8*data,u16 len);
//IIC1读寄存器
pl_t pl_iic1_rd_addr(u8 dev_addr,u8 reg_addr,u8*data,u16 len);

//IIC1等待
static pl_t iic1_wait()
{
	u8 t=0;
	while(IIC1.State!=HAL_I2C_STATE_READY)
	{
		osDelay(1);
		++t;
		if(t>IIC1_OVERTIME)
		{
			HAL_I2C_DeInit(&IIC1);
			HAL_I2C_Init(&IIC1);
			return PL_FAIL;
		}
	}
	return PL_OK;
}

//IIC1检查
static pl_t iic1_check()
{
	if(IIC1.ErrorCode!=HAL_I2C_ERROR_NONE)
	{
		HAL_I2C_DeInit(&IIC1);
		HAL_I2C_Init(&IIC1);
		return PL_FAIL;
	}else
	{
		return PL_OK;
	}
}

//IIC1写寄存器
pl_t pl_iic1_wt_addr(u8 dev_addr,u8 reg_addr,u8*data,u16 len)
{
	while(IIC1.State!=HAL_I2C_STATE_READY)
	{
		osDelay(1);
	}
	if(HAL_I2C_Mem_Write_IT(&IIC1,dev_addr,reg_addr,I2C_MEMADD_SIZE_8BIT,data,len)==HAL_OK)
	{
		iic1_wait();
		return iic1_check();
	}else
	{
		PL_LOG("pl_iic_wt_addr_err\n");
		iic1_check();
		return PL_FAIL;
	}
}

//IIC1读寄存器
pl_t pl_iic1_rd_addr(u8 dev_addr,u8 reg_addr,u8*data,u16 len)
{
	while(IIC1.State!=HAL_I2C_STATE_READY)
	{
		osDelay(1);
	}
	if(HAL_I2C_Mem_Read_IT(&IIC1,dev_addr,reg_addr,I2C_MEMADD_SIZE_8BIT,data,len)==HAL_OK)
	{
		iic1_wait();
		return iic1_check();
	}else
	{
		PL_LOG("pl_iic_rd_addr_err\n");
		iic1_check();
		return PL_FAIL;
	}
}

//IIC1写数据
pl_t pl_iic1_wt_data(u8 dev_addr,u8*data,u16 len)
{
	while(IIC1.State!=HAL_I2C_STATE_READY)
	{
		osDelay(1);
	}
	if(HAL_I2C_Master_Transmit_IT(&IIC1,dev_addr,data,len)==HAL_OK)
	{
		iic1_wait();
		return iic1_check();
	}else
	{
		PL_LOG("pl_iic_wt_data_err\n");
		iic1_check();
		return PL_FAIL;
	}
}
//IIC1读数据
pl_t pl_iic1_rd_data(u8 dev_addr,u8*data,u16 len)
{
	while(IIC1.State!=HAL_I2C_STATE_READY)
	{
		osDelay(1);
	}
	if(HAL_I2C_Master_Receive_IT(&IIC1,dev_addr,data,len)==HAL_OK)
	{
		iic1_wait();
		return iic1_check();
	}else
	{
		PL_LOG("pl_iic_rd_data_err\n");
		iic1_check();
		return PL_FAIL;
	}
}
