#include"pl_uart.h"

//依赖
#include<string.h>
#include<stdarg.h>
#include<stdio.h>

//串口1配置
extern UART_HandleTypeDef huart1;
#define PL_UART1 huart1
#define PL_UART1_MAX_TX_SIZE 128
#define PL_UART1_MAX_RX_SIZE 128

//串口1数据
typedef struct pl_uart1_data_t
{
    u8 tx_data[PL_UART1_MAX_TX_SIZE];
    u8 rx_data[PL_UART1_MAX_RX_SIZE];
    u16 rx_len;
}pl_uart1_data_t;
static pl_uart1_data_t pl_uart1_data={0};

//串口1发送字符串
void pl_uart1_tx_str(const char*data,...);
//串口1发送二进制
void pl_uart1_tx_bin(u8*data,u16 len);
//串口1接收字符串
void pl_uart1_rx_str(char*data,u16 len);
//串口1接收二进制
void pl_uart1_rx_bin(u8*data,u16*len);
//串口1超时接收字符串
pl_t pl_uart1_rx_str_time(u16 time,char*data,u16 len);
//串口1超时接收二进制
pl_t pl_uart1_rx_bin_time(u16 time,u8*data,u16*len);

//串口1发送字符串
void pl_uart1_tx_str(const char*data,...)
{
    //等待发送空闲
    while(PL_UART1.gState!=HAL_UART_STATE_READY)
    {
        osDelay(1);
    }
    //更新发送缓冲区
    memset(pl_uart1_data.tx_data,0,PL_UART1_MAX_TX_SIZE);
    va_list val;
    va_start(val,data);
    vsnprintf((char*)pl_uart1_data.tx_data,PL_UART1_MAX_TX_SIZE-1,data,val);
    va_end(val);
    //DMA发送
    HAL_UART_Transmit_DMA(&PL_UART1,(u8*)pl_uart1_data.tx_data,strlen((char*)pl_uart1_data.tx_data));
}

//串口1发送二进制
void pl_uart1_tx_bin(u8*data,u16 len)
{
    //等待发送空闲
    while(PL_UART1.gState!=HAL_UART_STATE_READY)
    {
        osDelay(1);
    }
    //DMA发送
    HAL_UART_Transmit_DMA(&PL_UART1,data,len);
}

//串口1接收字符串
void pl_uart1_rx_str(char*data,u16 len)
{
    //更新接收缓冲区
    memset(pl_uart1_data.rx_data,0,PL_UART1_MAX_RX_SIZE);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&PL_UART1,pl_uart1_data.rx_data,PL_UART1_MAX_RX_SIZE-1);
    while(PL_UART1.RxState!=HAL_UART_STATE_READY)
    {
        osDelay(1);
    }
    strncpy(data, (char*)pl_uart1_data.rx_data, len-1);
}

//串口1接收二进制
void pl_uart1_rx_bin(u8*data,u16*len)
{
    //更新接收缓冲区
    memset(pl_uart1_data.rx_data,0,PL_UART1_MAX_RX_SIZE);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&PL_UART1,pl_uart1_data.rx_data,PL_UART1_MAX_RX_SIZE-1);
    while(PL_UART1.RxState!=HAL_UART_STATE_READY)
    {
        osDelay(1);
    }
    memcpy(data, pl_uart1_data.rx_data, *len);
    *len=pl_uart1_data.rx_len;
}

//串口1超时接收字符串
pl_t pl_uart1_rx_str_time(u16 time,char*data,u16 len)
{
    //更新接收缓冲区
    memset(pl_uart1_data.rx_data,0,PL_UART1_MAX_RX_SIZE);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&PL_UART1,pl_uart1_data.rx_data,PL_UART1_MAX_RX_SIZE-1);
    u16 time_=0;
    while(PL_UART1.RxState!=HAL_UART_STATE_READY)
    {
        if(time_>time)
        {
            return PL_FAIL;
        }
        ++time_;
        osDelay(1);
    }
    strncpy(data, (char*)pl_uart1_data.rx_data, len-1);
    return PL_OK;
}

//串口1超时接收二进制
pl_t pl_uart1_rx_bin_time(u16 time,u8*data,u16*len)
{
    //更新接收缓冲区
    memset(pl_uart1_data.rx_data,0,PL_UART1_MAX_RX_SIZE);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&PL_UART1,pl_uart1_data.rx_data,PL_UART1_MAX_RX_SIZE-1);
    u16 time_=0;
    while(PL_UART1.RxState!=HAL_UART_STATE_READY)
    {
        if(time_>time)
        {
            return PL_FAIL;
        }
        ++time_;
        osDelay(1);
    }
    memcpy(data, pl_uart1_data.rx_data, *len);
    *len=pl_uart1_data.rx_len;
    return PL_OK;
}

//串口总接收回调函数
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef*huart,uint16_t len);

//串口总接收回调函数
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef*huart,uint16_t len)
{
    if(huart->Instance==PL_UART1.Instance)
    {
        pl_uart1_data.rx_len=len;
    }
}
