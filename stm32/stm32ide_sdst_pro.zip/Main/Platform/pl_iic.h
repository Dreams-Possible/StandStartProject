#pragma once

//依赖
#include"pl_sys.h"

//CubeIDE中按如下配置
//启用硬件IIC
//启用IIC中断
//其余默认即可

//IIC1写数据
pl_t pl_iic1_wt_data(u8 dev_addr,u8*data,u16 len);
//IIC1读数据
pl_t pl_iic1_rd_data(u8 dev_addr,u8*data,u16 len);
//IIC1写寄存器
pl_t pl_iic1_wt_addr(u8 dev_addr,u8 reg_addr,u8*data,u16 len);
//IIC1读寄存器
pl_t pl_iic1_rd_addr(u8 dev_addr,u8 reg_addr,u8*data,u16 len);
