#include"pl_sys.h"

// 依赖
#include"User/us_app.h"

//初始化应用
void pl_sys_init();
//应用
static void sys_main(void*arg);

//任务句柄
static osThreadId_t ThreadId;
static osThreadAttr_t ThreadAttr=
{
    .name="us_app",
    .stack_size=128*16,
    .priority=(osPriority_t)osPriorityNormal,
};

//初始化应用
void pl_sys_init()
{
    ThreadId=osThreadNew(sys_main,NULL,&ThreadAttr);
}

//转到应用
static void sys_main(void*arg)
{
    us_app();
    osThreadExit();
}
