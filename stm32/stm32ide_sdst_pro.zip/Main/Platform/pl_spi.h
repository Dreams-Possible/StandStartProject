#pragma once
#include"pl_sys.h"

//CubeIDE中按如下配置
//任意引脚命名为：SP1_CS
//启用硬件SPI
//启用SPI中断
//其余默认即可

//SPI1开始
void pl_spi1_start();
//SPI1结束
void pl_spi1_end();
//SPI1发送
void pl_spi1_tx(u8*data,u16 len);
//SPI1接收
void pl_spi1_rx(u8*data,u16 len);
//SPI1发送接收
void pl_spi1_txrx(u8*tx,u8*rx,u16 len);
