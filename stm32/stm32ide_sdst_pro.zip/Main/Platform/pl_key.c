#include"pl_key.h"

//定义
#define KEY1 HAL_GPIO_ReadPin(Key1_GPIO_Port,Key1_Pin)
#define KEY2 HAL_GPIO_ReadPin(Key2_GPIO_Port,Key2_Pin)

//按键数据
typedef struct key_data_t
{
	u8 key1;
	u8 key2;
}key_data_t;
static key_data_t key_data={0};

//按键1扫描
static void key1_scan(void*arg);
//按键2扫描
static void key2_scan(void*arg);
//按键初始化
pl_t pl_key_init();
//按键读取
void pl_key_read(u8*key1,u8*key2);

//按键1扫描
static void key1_scan(void*arg)
{
	while (1)
	{
		if(KEY1==0)
		{
			//延迟50ms由于消抖
			osDelay(50);
			if(KEY1==0)
			{
				++key_data.key1;
			}else
			{
				continue;
			}
		}else
		{
			osDelay(10);
		}
	}
}

//按键2扫描
static void key2_scan(void*arg)
{
	while (1)
	{
		if(KEY2==0)
		{
			//延迟50ms由于消抖
			osDelay(50);
			if(KEY2==0)
			{
				++key_data.key2;
			}else
			{
				continue;;
			}
		}else
		{
			osDelay(10);
		}
	}
}

//按键初始化
pl_t pl_key_init()
{
	osThreadAttr_t ThreadAttr=
	{
		.name="keys_scan",
		.stack_size=128*4,
		.priority=(osPriority_t)osPriorityNormal,
	};
	osThreadId_t key1_task = osThreadNew(key1_scan,NULL,&ThreadAttr);
	if(!key1_task)
	{
		return PL_FAIL;
	}
	osThreadId_t key2_task = osThreadNew(key2_scan,NULL,&ThreadAttr);
	if(!key2_task)
	{
		osThreadTerminate(key1_task);
		return PL_FAIL;
	}
	return PL_OK;
}

//按键读取
void pl_key_read(u8*key1,u8*key2)
{
	if(key1)
	{
		*key1=key_data.key1;
	}
	if(key2)
	{
		*key2=key_data.key2;
	}
}
