#include"pl_motor.h"

//定义
extern TIM_HandleTypeDef htim1;
#define MOTOR_TIMER htim1
#define MOTOR1_TMCH TIM_CHANNEL_1
#define MOTOR2_TMCH TIM_CHANNEL_4
#define FULL_TIMER_COUNTER 65535
#define AIN1_1(x) HAL_GPIO_WritePin(AIN1_1_GPIO_Port,AIN1_1_Pin,(GPIO_PinState)(x))
#define AIN2_1(x) HAL_GPIO_WritePin(AIN2_1_GPIO_Port,AIN2_1_Pin,(GPIO_PinState)(x))
#define BIN1_1(x) HAL_GPIO_WritePin(BIN1_1_GPIO_Port,BIN1_1_Pin,(GPIO_PinState)(x))
#define BIN2_1(x) HAL_GPIO_WritePin(BIN2_1_GPIO_Port,BIN2_1_Pin,(GPIO_PinState)(x))

//电机数据
typedef struct motor_data_t
{
	float motor1;
	float motor2;
}motor_data_t;
static motor_data_t motor_data={0};

//电机1初始化
static pl_t motor1_init();
//电机2初始化
static pl_t motor2_init();
//电机总初始化
pl_t pl_motors_init();
//电机1设置
static void motor1_set();
//电机2设置
static void motor2_set();
//电机总设置
void pl_motors_set(float motor1,float motor2);
//电机总读取
void pl_motors_read(float*motor1,float*motor2);

//电机1初始化
static pl_t motor1_init()
{
	if(HAL_TIM_PWM_Start(&MOTOR_TIMER,MOTOR1_TMCH)!=HAL_OK)
	{
		return PL_FAIL;
	}
	return PL_OK;
}

//电机2初始化
static pl_t motor2_init()
{
	if(HAL_TIM_PWM_Start(&MOTOR_TIMER,MOTOR2_TMCH)!=HAL_OK)
	{
		return PL_FAIL;
	}
	return PL_OK;
}

//电机总初始化
pl_t pl_motors_init()
{
	if(motor1_init()!=PL_OK)
	{
		return PL_FAIL;
	}
	if(motor2_init()!=PL_OK)
	{
		return PL_FAIL;
	}
	return PL_OK;
}

//电机1设置
static void motor1_set()
{
	//限制速度
	if(motor_data.motor1>100)
	{
		motor_data.motor1=100;
	}else
	if(motor_data.motor1<-100)
	{
		motor_data.motor1=-100;
	}
	//设置速度
	if(motor_data.motor1>=0)
	{
		AIN1_1(1);
		AIN2_1(0);
		__HAL_TIM_SetCompare(&MOTOR_TIMER,MOTOR1_TMCH,(i16)(motor_data.motor1/100*FULL_TIMER_COUNTER));
	}else
	if(motor_data.motor1<=0)
	{
		AIN1_1(0);
		AIN2_1(1);
		__HAL_TIM_SetCompare(&MOTOR_TIMER,MOTOR1_TMCH,(i16)(-motor_data.motor1/100*FULL_TIMER_COUNTER));
	}
}

//电机2设置
static void motor2_set()
{
	//限制速度
	if(motor_data.motor2>100)
	{
		motor_data.motor2=100;
	}else
	if(motor_data.motor2<-100)
	{
		motor_data.motor2=-100;
	}
	//设置速度
	if(motor_data.motor2>=0)
	{
		BIN1_1(1);
		BIN2_1(0);
		__HAL_TIM_SetCompare(&MOTOR_TIMER,MOTOR2_TMCH,(i16)(motor_data.motor2/100*FULL_TIMER_COUNTER));
	}else
	if(motor_data.motor2<=0)
	{
		BIN1_1(0);
		BIN2_1(1);
		__HAL_TIM_SetCompare(&MOTOR_TIMER,MOTOR2_TMCH,(i16)(-motor_data.motor2/100*FULL_TIMER_COUNTER));
	}
}

//电机总设置
void pl_motors_set(float motor1,float motor2)
{
	motor_data.motor1=motor1;
	motor1_set();

	motor_data.motor2=motor2;
	motor2_set();
}

//电机总读取
void pl_motors_read(float*motor1,float*motor2)
{
	if(motor1)
	{
		*motor1=motor_data.motor1;
	}
	if(motor2)
	{
		*motor2=motor_data.motor2;
	}
}