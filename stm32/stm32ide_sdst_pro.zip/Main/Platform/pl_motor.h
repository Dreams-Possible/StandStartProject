#pragma once

//依赖
#include"pl_sys.h"

//CubeIDE中按如下配置
//配置定时器为
//预分频系数0，计数周期为FULL_TIMER_COUNTER-1，频率为0~FULL_TIMER_COUNTER
//并分配对应PWM通道
//配置任意引脚名称为
//Motor1_Ain1，Motor1_Ain2，Motor1_Bin1，Motor1_Bin2，以此类推
//其余默认即可

//电机总初始化
pl_t pl_motors_init();
//电机总设置
void pl_motors_set(float motor1,float motor2);
//电机总读取
void pl_motors_read(float*motor1,float*motor2);
