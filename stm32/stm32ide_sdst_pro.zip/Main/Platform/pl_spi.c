#include"pl_spi.h"

//定义
extern SPI_HandleTypeDef hspi1;
#define SPI1_RD hspi1
#define SPI1_CSMD 0
#define SPI1_CS(x) HAL_GPIO_WritePin(SPI1_CS_GPIO_Port,SPI1_CS_Pin,(GPIO_PinState)(x))

//SPI1开始
void pl_spi1_start();
//SPI1结束
void pl_spi1_end();
//SPI1发送
void pl_spi1_tx(u8*data,u16 len);
//SPI1接收
void pl_spi1_rx(u8*data,u16 len);
//SPI1发送接收
void pl_spi1_txrx(u8*tx,u8*rx,u16 len);

//SPI1开始
void pl_spi1_start()
{
	SPI1_CS(SPI1_CSMD);
}

//SPI1结束
void pl_spi1_end()
{
	SPI1_CS(1-SPI1_CSMD);
}

//SPI1发送
void pl_spi1_tx(u8*data,u16 len)
{
	while(SPI1_RD.State!=HAL_SPI_STATE_READY)
	{
		osDelay(1);
	}
	HAL_SPI_Transmit_IT(&SPI1_RD,data,len);
}

//SPI1接收
void pl_spi1_rx(u8*data,u16 len)
{
	while(SPI1_RD.State!=HAL_SPI_STATE_READY)
	{
		osDelay(1);
	}
	HAL_SPI_Receive_IT(&SPI1_RD,data,len);
	while(SPI1_RD.State!=HAL_SPI_STATE_READY)
	{
		osDelay(1);
	}
}

//SPI1发送接收
void pl_spi1_txrx(u8*tx,u8*rx,u16 len)
{
	while(SPI1_RD.State!=HAL_SPI_STATE_READY)
	{
		osDelay(1);
	}
	HAL_SPI_TransmitReceive_IT(&SPI1_RD,tx,rx,len);
	while(SPI1_RD.State!=HAL_SPI_STATE_READY)
	{
		osDelay(1);
	}
}
