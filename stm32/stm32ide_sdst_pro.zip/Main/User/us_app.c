#include"us_app.h"

//依赖
#include"Platform/pl_uart.h"
#include"Platform/pl_key.h"
#include"Platform/pl_encoder.h"
#include"Platform/pl_motor.h"
#include"Platform/pl_iic.h"
#include"Platform/pl_spi.h"

//用户应用
void us_app();

//用户应用
void us_app()
{
	PL_LOG("us_app_load\n");

    //初始化
    while (pl_key_init()!=PL_OK)
    {
        PL_LOG("key_init_fail\n");
        osDelay(1000);
    }
    PL_LOG("key_init_ok\n");
    while (pl_encoders_init()!=PL_OK)
    {
        PL_LOG("encoders_init_fail\n");
        osDelay(1000);
    }
    PL_LOG("encoders_init_ok\n");
    while (pl_motors_init()!=PL_OK)
    {
        PL_LOG("motors_init_fail\n");
        osDelay(1000);
    }
    PL_LOG("motors_init_ok\n");

    //测试用例
    while(1)
    {
        pl_uart1_tx_str("wait...\n");
        //从串口输入
        u16 len=32;
        u8 data[32]={0};
        //串口接收二进制
        pl_uart1_rx_bin(data,&len);
        //串口发送二进制
        pl_uart1_tx_bin(data,len);
        osDelay(10);
    }

}
