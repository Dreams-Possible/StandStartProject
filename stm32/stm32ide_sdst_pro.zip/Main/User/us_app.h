#pragma once

//依赖
#include"Platform/pl_sys.h"

//用户应用
void us_app();
