#pragma once

//依赖
#include"main.h"
#include"cmsis_os.h"

//参数定义
typedef uint8_t u8;
typedef int8_t i8;
typedef uint16_t u16;
typedef int16_t i16;
typedef uint32_t u32;
typedef int32_t i32;
typedef u8 pl_t;
#define SP_OK 0
#define SP_FAIL 1
#define SP_LOG(fmt,...) pl_uart1_tx_str("[SP_INFO][%s:%d:%s]: "fmt"\n",__FILE__,__LINE__,__func__,##__VA_ARGS__)

//初始化应用
void pl_sys_init();
