#include"pl_sys.h"

// 依赖
#include"User/us_app.h"

//初始化应用
void pl_sys_init();
//应用
static void sys_main(void*argument);

//任务句柄
static osThreadId_t appTask_Handle;
static osThreadAttr_t appTask_Attributes=
{
    .name="us_app",
    .stack_size=128*16,
    .priority=(osPriority_t)osPriorityNormal,
};

//初始化应用
void pl_sys_init()
{
    appTask_Handle=osThreadNew(sys_main,NULL,&appTask_Attributes);
}

//转到应用
static void sys_main(void*argument)
{
    us_app();
    osThreadExit();
}
