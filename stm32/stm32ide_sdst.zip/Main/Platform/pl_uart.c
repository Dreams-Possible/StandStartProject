#include"pl_uart.h"

//依赖
#include<string.h>
#include<stdarg.h>
#include<stdio.h>

//串口1配置
extern UART_HandleTypeDef huart1;
#define SP_UART1 huart1
#define SP_UART1_MAX_TX_LEN 128
#define SP_UART1_MAX_RX_LEN 128

//串口1数据
typedef struct pl_uart1_data_t
{
    u8 tx_data[SP_UART1_MAX_TX_LEN];
    u8 rx_data[SP_UART1_MAX_RX_LEN];
    u16 rx_len;
}pl_uart1_data_t;
static pl_uart1_data_t pl_uart1_data={0};

//串口1发送
void pl_uart1_tx(const char*data,...);
//串口1直接发送
void pl_uart1_tx_dir(u8*data,u16 len);
//串口1接收
char*pl_uart1_rx();
//串口1直接接收
void pl_uart1_rx_dir(u8**data,u16*len);
//串口1超时接收
char*pl_uart1_rx_time(u16 time);

//串口1发送
void pl_uart1_tx(const char*data,...)
{
    //等待发送空闲
    while(SP_UART1.gState!=HAL_UART_STATE_READY)
    {
        // SP_LOG("uart wait\n");
        osDelay(1);
    }
    //更新发送缓冲区
    memset(pl_uart1_data.tx_data,0,SP_UART1_MAX_TX_LEN);
    va_list val;
    va_start(val,data);
    vsnprintf((char*)pl_uart1_data.tx_data,SP_UART1_MAX_TX_LEN,data,val);
    va_end(val);
    //DMA发送
    HAL_UART_Transmit_DMA(&SP_UART1,(u8*)pl_uart1_data.tx_data,strlen((char*)pl_uart1_data.tx_data));
}

//串口1直接发送
void pl_uart1_tx_dir(u8*data,u16 len)
{
    //等待发送空闲
    while(SP_UART1.gState!=HAL_UART_STATE_READY)
    {
        // SP_LOG("uart wait\n");
        osDelay(1);
    }
    //DMA发送
    HAL_UART_Transmit_DMA(&SP_UART1,data,len);
}

//串口1接收
char*pl_uart1_rx()
{
    //更新接收缓冲区
    memset(pl_uart1_data.rx_data,0,SP_UART1_MAX_RX_LEN);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&SP_UART1,pl_uart1_data.rx_data,SP_UART1_MAX_RX_LEN);
    while(SP_UART1.RxState!=HAL_UART_STATE_READY)
    {
        osDelay(1);
    }
    return (char*)pl_uart1_data.rx_data;
}

//串口1直接接收
void pl_uart1_rx_dir(u8**data,u16*len)
{
    //更新接收缓冲区
    memset(pl_uart1_data.rx_data,0,SP_UART1_MAX_RX_LEN);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&SP_UART1,pl_uart1_data.rx_data,SP_UART1_MAX_RX_LEN);
    while(SP_UART1.RxState!=HAL_UART_STATE_READY)
    {
        osDelay(1);
    }
    *data=pl_uart1_data.rx_data;
    *len=pl_uart1_data.rx_len;
}

//串口1超时接收
char*pl_uart1_rx_time(u16 time)
{
    //更新接收缓冲区
    memset(pl_uart1_data.rx_data,0,SP_UART1_MAX_RX_LEN);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&SP_UART1,pl_uart1_data.rx_data,SP_UART1_MAX_RX_LEN);
    u16 time_=0;
    while(SP_UART1.RxState!=HAL_UART_STATE_READY)
    {
        if(time_>time)
        {
            return NULL;
        }
        ++time_;
        osDelay(1);
    }
    return (char*)pl_uart1_data.rx_data;
}


//串口2配置
extern UART_HandleTypeDef huart2;
#define SP_UART2 huart2
#define SP_UART2_MAX_TX_LEN 128
#define SP_UART2_MAX_RX_LEN 128

//串口2数据
typedef struct pl_uart2_data_t
{
    u8 tx_data[SP_UART2_MAX_TX_LEN];
    u8 rx_data[SP_UART2_MAX_RX_LEN];
    u16 rx_len;
}pl_uart2_data_t;
static pl_uart2_data_t pl_uart2_data={0};

//串口2发送
void pl_uart2_tx(const char*data,...);
//串口2直接发送
void pl_uart2_tx_dir(u8*data,u16 len);
//串口2接收
char*pl_uart2_rx();
//串口2直接接收
void pl_uart2_rx_dir(u8**data,u16*len);
//串口2超时接收
char*pl_uart2_rx_time(u16 time);

//串口2发送
void pl_uart2_tx(const char*data,...)
{
    //等待发送空闲
    while(SP_UART2.gState!=HAL_UART_STATE_READY)
    {
        // SP_LOG("uart wait\n");
        osDelay(1);
    }
    //更新发送缓冲区
    memset(pl_uart2_data.tx_data,0,SP_UART2_MAX_TX_LEN);
    va_list val;
    va_start(val,data);
    vsnprintf((char*)pl_uart2_data.tx_data,SP_UART2_MAX_TX_LEN,data,val);
    va_end(val);
    //DMA发送
    HAL_UART_Transmit_DMA(&SP_UART2,(u8*)pl_uart2_data.tx_data,strlen((char*)pl_uart2_data.tx_data));
}

//串口2直接发送
void pl_uart2_tx_dir(u8*data,u16 len)
{
    //等待发送空闲
    while(SP_UART2.gState!=HAL_UART_STATE_READY)
    {
        // SP_LOG("uart wait\n");
        osDelay(1);
    }
    //DMA发送
    HAL_UART_Transmit_DMA(&SP_UART2,data,len);
}

//串口2接收
char*pl_uart2_rx()
{
    //更新接收缓冲区
    memset(pl_uart2_data.rx_data,0,SP_UART2_MAX_RX_LEN);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&SP_UART2,pl_uart2_data.rx_data,SP_UART2_MAX_RX_LEN);
    while(SP_UART2.RxState!=HAL_UART_STATE_READY)
    {
        osDelay(1);
    }
    return (char*)pl_uart2_data.rx_data;
}

//串口2直接接收
void pl_uart2_rx_dir(u8**data,u16*len)
{
    //更新接收缓冲区
    memset(pl_uart2_data.rx_data,0,SP_UART2_MAX_RX_LEN);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&SP_UART2,pl_uart2_data.rx_data,SP_UART2_MAX_RX_LEN);
    while(SP_UART2.RxState!=HAL_UART_STATE_READY)
    {
        osDelay(1);
    }
    *data=pl_uart2_data.rx_data;
    *len=pl_uart2_data.rx_len;
}

//串口2超时接收
char*pl_uart2_rx_time(u16 time)
{
    //更新接收缓冲区
    memset(pl_uart2_data.rx_data,0,SP_UART2_MAX_RX_LEN);
    //等待接收数据
    HAL_UARTEx_ReceiveToIdle_DMA(&SP_UART2,pl_uart2_data.rx_data,SP_UART2_MAX_RX_LEN);
    u16 time_=0;
    while(SP_UART2.RxState!=HAL_UART_STATE_READY)
    {
        if(time_>time)
        {
            return NULL;
        }
        ++time_;
        osDelay(1);
    }
    return (char*)pl_uart2_data.rx_data;
}

//串口1接收回调函数
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef*huart,uint16_t len);

//串口1接收回调函数
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef*huart,uint16_t len)
{
    if(huart->Instance==SP_UART1.Instance)
    {
        pl_uart1_data.rx_len=len;
    }else
    if(huart->Instance==SP_UART2.Instance)
    {
        pl_uart2_data.rx_len=len;
    }
}
