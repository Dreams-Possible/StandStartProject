#pragma once

//依赖
#include"pl_sys.h"

//CubeIDE中按如下配置
//启用串口
//启用TX和RX的DMA通道
//启用串口中断
//其余默认即可

//串口1发送
void pl_uart1_tx(const char*data,...);
//串口1直接发送
void pl_uart1_tx_dir(u8*data,u16 len);
//串口1接收
char*pl_uart1_rx();
//串口1直接接收
void pl_uart1_rx_dir(u8**data,u16*len);
//串口1超时接收
char*pl_uart1_rx_time(u16 time);

//串口2发送
void pl_uart2_tx(const char*data,...);
//串口2直接发送
void pl_uart2_tx_dir(u8*data,u16 len);
//串口2接收
char*pl_uart2_rx();
//串口2直接接收
void pl_uart2_rx_dir(u8**data,u16*len);
//串口2超时接收
char*pl_uart2_rx_time(u16 time);
