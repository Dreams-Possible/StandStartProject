#include"us_app.h"

//依赖
#include"Platform/pl_uart.h"

//用户应用
void us_app();

//用户应用
void us_app()
{
	SP_LOG("us_app_load\n");

    
    while(1)
    {
        pl_uart1_tx("start\n");
        //从串口输入
        u8*data=NULL;
        u16 len=0;
        // //串口接收
        // data=pl_uart1_rx();
        //串口直接接收
        pl_uart1_rx_dir(&data,&len);
        // //串口发送
        // pl_uart1_tx(data);
        //串口直接发送
        pl_uart1_tx_dir(data,len);
        osDelay(10);
    }


}
