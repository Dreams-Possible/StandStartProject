################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Main/User/us_app.c 

OBJS += \
./Main/User/us_app.o 

C_DEPS += \
./Main/User/us_app.d 


# Each subdirectory must supply rules for building sources it contributes
Main/User/%.o Main/User/%.su Main/User/%.cyclo: ../Main/User/%.c Main/User/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM3 -I"C:/Users/Windows/Documents/STM32CubeIDE/workspace_1.19.0/stm32ide_sdst/Main" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Main-2f-User

clean-Main-2f-User:
	-$(RM) ./Main/User/us_app.cyclo ./Main/User/us_app.d ./Main/User/us_app.o ./Main/User/us_app.su

.PHONY: clean-Main-2f-User

